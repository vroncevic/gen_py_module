# -*- coding: UTF-8 -*-

'''
Module
    ${MOD}.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines class ${MODCL} with attribute(s) and method(s).
'''

from __future__ import annotations

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'GNU General Public License (GPL)'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class ${MODCL}:
    '''
        Defines class ${MODCL} with attribute(s) and method(s).

        It defines:

            :attributes:
                | _is_initialized - Initialization state flag.
                | _verbose - Verbose execution flag.
            :methods:
                | __init__ - Initializes ${MODCL} constructor.
                | execute - Executes ${MODCL} operation.
                | is_initialized - Checks if ${MODCL} is initialized.
    '''

    _is_initialized: bool
    _verbose: bool

    def __init__(self, verbose: bool = False) -> None:
        '''
            Initializes ${MODCL} constructor.

            :param verbose: Enable/Disable verbose option.
            :exceptions: None.
        '''
        self._verbose = verbose
        self._is_initialized = True

    def execute(self) -> bool:
        '''
            Executes ${MODCL} operation.

            :return: True if operation succeeded, False otherwise.
            :exceptions: None.
        '''
        return self._is_initialized or self._verbose

    def is_initialized(self) -> bool:
        '''
            Checks if ${MODCL} is initialized.

            :return: True if initialized, False otherwise.
            :exceptions: None.
        '''
        return self._is_initialized
