# -*- coding: UTF-8 -*-

'''
Module
    i${MOD}.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines structural protocol interface I${MODCL}.
'''

from __future__ import annotations

from typing import Protocol, runtime_checkable

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'GNU General Public License (GPL)'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


@runtime_checkable
class I${MODCL}(Protocol):
    '''
        Defines structural protocol interface I${MODCL}.

        It defines:

            :methods:
                | execute - Executes contract operation.
                | is_initialized - Checks if implementation is initialized.
    '''

    def execute(self) -> bool:
        '''
            Executes contract operation.

            :return: True if operation succeeded, False otherwise.
        '''

    def is_initialized(self) -> bool:
        '''
            Checks if implementation is initialized.

            :return: True if initialized, False otherwise.
        '''
