# -*- coding: UTF-8 -*-

'''
Module
    ${MOD}_abc.py
Copyright
    Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>
    ${PRO} is free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by the
    Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    ${PRO} is distributed in the hope that it will be useful, but
    WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
    See the GNU General Public License for more details.
    You should have received a copy of the GNU General Public License along
    with this program. If not, see <http://www.gnu.org/licenses/>.
Info
    Defines abstract base class ${MODCL}ABC with attribute(s) and method(s).
'''

from __future__ import annotations

from abc import ABCMeta, abstractmethod

__author__ = 'Vladimir Roncevic'
__copyright__ = 'Copyright (C) ${YEAR} Vladimir Roncevic <elektron.ronca@gmail.com>'
__credits__ = ['Vladimir Roncevic', 'Python Software Foundation']
__license__ = 'GNU General Public License (GPL)'
__version__ = '1.0.0'
__maintainer__ = 'Vladimir Roncevic'
__email__ = 'elektron.ronca@gmail.com'
__status__ = 'Updated'


class ${MODCL}ABC(metaclass=ABCMeta):
    '''
        Defines abstract base class ${MODCL}ABC with attribute(s) and method(s).

        It defines:

            :attributes:
                | _verbose - Verbose execution flag.
            :methods:
                | __init__ - Initializes ${MODCL}ABC constructor.
                | is_verbose - Checks if verbose mode is enabled.
                | execute - Abstract method to be implemented by subclasses.
    '''

    _verbose: bool

    def __init__(self, verbose: bool = False) -> None:
        '''
            Initializes ${MODCL}ABC constructor.

            :param verbose: Enable/Disable verbose option.
            :exceptions: None.
        '''
        self._verbose = verbose

    def is_verbose(self) -> bool:
        '''
            Checks if verbose mode is enabled.

            :return: True if verbose mode is enabled, False otherwise.
            :exceptions: None.
        '''
        return self._verbose

    @abstractmethod
    def execute(self) -> bool:
        '''
            Abstract method to be implemented by subclasses.

            :return: Execution status.
        '''
